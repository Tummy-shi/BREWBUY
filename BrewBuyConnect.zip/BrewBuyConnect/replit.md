# BrewBuy - Premium Beer, Ale & Cider E-Commerce App

## Overview
BrewBuy is a mobile-first web application for purchasing craft beers, ales, and ciders. Built with React, TailwindCSS, and Supabase, it features real-time stock updates, live chat support, order tracking, and a seamless shopping experience inspired by Ionic mobile design patterns.

## Recent Changes (November 13, 2025)
- Created complete schema with tables for users, products, orders, order_items, service_requests, and chat_messages
- Built all frontend components with Ionic-inspired mobile-first design
- Implemented Splash screen with app icon and loading animation
- Created Login/Register pages with Supabase Auth integration
- Built Dashboard with product grid and real-time stock monitoring
- Developed Shopping Cart with quantity management
- Created Checkout flow with order summary
- Implemented Order/Service Tracking page with real-time status updates
- Built Live Chat interface with message bubbles
- Created all static pages: Company History, About Products, About App, Developers, Contact Us
- Configured design system with Inter font and amber/orange primary color scheme
- Generated product images for beers, ales, and ciders
- Set up authentication and cart context providers
- Configured routing for all pages with protected routes

## Project Architecture

### Frontend (client/src/)
- **React + TypeScript** - Component-based UI with strong typing
- **TailwindCSS** - Utility-first CSS with custom design tokens
- **Wouter** - Lightweight routing
- **TanStack Query** - Server state management (though most data fetching uses Supabase client directly)
- **Supabase Client** - Direct client integration for all backend features

### Backend Architecture
**Important:** This app uses Supabase as a Backend-as-a-Service (BaaS), not a traditional Express backend. All backend functionality (database, auth, realtime) is provided by Supabase and accessed directly from the client. This is the standard and recommended Supabase pattern.

- **Supabase** - Complete backend solution:
  - PostgreSQL database with Row Level Security
  - Real-time subscriptions via WebSocket channels
  - Email/password authentication
  - Auto-generated REST API
  - User management

The Express server in this project only serves the Vite frontend - all data operations go directly to Supabase from the client using the Supabase JavaScript client library.

### Key Features
1. **Authentication** - Email/password signup and login via Supabase Auth
2. **Product Browsing** - Real-time product catalog with stock counts
3. **Shopping Cart** - Client-side cart with localStorage persistence
4. **Checkout** - Mock payment with order creation
5. **Order Tracking** - Real-time order and service request status updates
6. **Live Chat** - Real-time messaging with support staff
7. **Responsive Design** - Mobile-first with Ionic-inspired UI

## Database Schema

### Tables
- **users** - User profiles (id, email, full_name, phone, profile_image)
- **products** - Product catalog (id, name, type, price, stock, image_url, alcohol_content)
- **orders** - Customer orders (id, user_id, status, total_amount, shipping_address)
- **order_items** - Order line items (id, order_id, product_id, quantity, price_at_purchase)
- **service_requests** - Customer service requests (id, user_id, product_id, description, status)
- **chat_messages** - Live chat messages (id, user_id, message, is_staff)

## User Preferences
- Mobile-first design approach
- Ionic-inspired UI components
- Real-time features for stock, orders, and chat
- Clean, modern aesthetic with rounded elements
- Amber/orange primary color scheme

## Environment Variables
- VITE_SUPABASE_URL - Supabase project URL
- VITE_SUPABASE_ANON_KEY - Supabase anonymous key

## Setup Required

**IMPORTANT:** Before using the app, you must set up the Supabase database:

1. Open your Supabase project at https://supabase.com
2. Go to SQL Editor
3. Run the complete SQL script from `supabase-setup.sql`
4. (Optional but recommended) Enable Realtime for tables: products, chat_messages, orders, service_requests

See `SETUP_INSTRUCTIONS.md` for detailed steps.

## Current Status

✅ All frontend components built and styled
✅ Supabase client integration complete
✅ Authentication flow implemented
✅ Real-time subscriptions configured
✅ All routing and navigation working
✅ Shopping cart with localStorage persistence
✅ Responsive mobile-first design
⏳ Waiting for user to run database setup SQL

Once the database is set up, all features will be fully functional.
