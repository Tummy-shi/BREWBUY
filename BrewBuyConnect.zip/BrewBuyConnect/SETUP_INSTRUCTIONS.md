# BrewBuy Setup Instructions

## Supabase Database Setup

To get BrewBuy up and running, you need to set up the database tables in your Supabase project.

### Step 1: Access Supabase SQL Editor
1. Go to your Supabase project dashboard at https://supabase.com
2. Click on "SQL Editor" in the left sidebar
3. Click "New Query"

### Step 2: Run the Setup SQL
1. Open the `supabase-setup.sql` file in this project
2. Copy all the SQL code
3. Paste it into the Supabase SQL Editor
4. Click "Run" to execute the script

This will create:
- All necessary database tables (users, products, orders, order_items, service_requests, chat_messages)
- Row Level Security policies for data protection
- Indexes for better performance
- Sample product data to get started

### Step 3: Verify Setup
After running the SQL:
1. Click on "Table Editor" in the Supabase sidebar
2. You should see all the tables listed
3. Click on "products" table - you should see 6 sample products

### Step 4: Enable Realtime (Optional but Recommended)
For live chat and real-time stock updates:
1. Go to "Database" → "Replication" in Supabase
2. Enable replication for these tables:
   - products (for real-time stock updates)
   - chat_messages (for live chat)
   - orders (for order status updates)
   - service_requests (for service request updates)

### Step 5: Test the Application
1. The app is now ready to use
2. Start by creating an account on the login page
3. Browse products, add to cart, and test the checkout flow
4. Try the live chat feature
5. Submit a service request
6. Track your orders

## Features Available

✅ User Authentication (Email/Password)
✅ Product Browsing with Real-time Stock Counts
✅ Shopping Cart
✅ Checkout & Order Placement
✅ Order & Service Request Tracking
✅ Live Chat with Support
✅ Multiple Static Information Pages

## Troubleshooting

**Issue: Can't create account**
- Check that your Supabase Auth settings allow email signups
- Go to Authentication → Settings in Supabase
- Enable "Email Auth"

**Issue: Products not showing**
- Verify the products table was created with sample data
- Check Row Level Security policies are in place
- The products table should have a policy: "Anyone can view products"

**Issue: Chat messages not updating in real-time**
- Ensure Realtime is enabled for the chat_messages table
- Check browser console for connection errors

**Issue: Orders not being created**
- Check that all tables were created successfully
- Verify RLS policies are correctly set up
- Check browser console for errors

## Next Steps

After setup, you can:
- Customize product data in the Supabase Table Editor
- Add more products
- Modify order statuses to test the tracking feature
- Send staff messages in chat (set is_staff to true in table editor)
