import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { CartProvider } from "@/contexts/CartContext";

import SplashScreen from "@/pages/splash-screen";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Cart from "@/pages/cart";
import Checkout from "@/pages/checkout";
import Tracking from "@/pages/tracking";
import Chat from "@/pages/chat";
import CompanyHistory from "@/pages/company-history";
import AboutProducts from "@/pages/about-products";
import AboutApp from "@/pages/about-app";
import Developers from "@/pages/developers";
import Contact from "@/pages/contact";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/login" />;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={SplashScreen} />
      <Route path="/login" component={Login} />
      <Route path="/dashboard">
        {() => <ProtectedRoute component={Dashboard} />}
      </Route>
      <Route path="/cart">
        {() => <ProtectedRoute component={Cart} />}
      </Route>
      <Route path="/checkout">
        {() => <ProtectedRoute component={Checkout} />}
      </Route>
      <Route path="/tracking">
        {() => <ProtectedRoute component={Tracking} />}
      </Route>
      <Route path="/chat">
        {() => <ProtectedRoute component={Chat} />}
      </Route>
      <Route path="/company-history">
        {() => <ProtectedRoute component={CompanyHistory} />}
      </Route>
      <Route path="/about-products">
        {() => <ProtectedRoute component={AboutProducts} />}
      </Route>
      <Route path="/about-app">
        {() => <ProtectedRoute component={AboutApp} />}
      </Route>
      <Route path="/developers">
        {() => <ProtectedRoute component={Developers} />}
      </Route>
      <Route path="/contact">
        {() => <ProtectedRoute component={Contact} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <CartProvider>
            <Toaster />
            <Router />
          </CartProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
