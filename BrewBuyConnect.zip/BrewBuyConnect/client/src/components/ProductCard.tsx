import { useState } from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/hooks/use-toast';
import { ShoppingCart, Wrench } from 'lucide-react';
import type { Product } from '@shared/schema';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface ProductCardProps {
  product: Product;
  onServiceRequest?: (productId: string, description: string) => void;
}

export function ProductCard({ product, onServiceRequest }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [showServiceDialog, setShowServiceDialog] = useState(false);
  const [serviceDescription, setServiceDescription] = useState('');

  const handleBuyNow = () => {
    if (product.stock <= 0) {
      toast({
        title: 'Out of Stock',
        description: 'This product is currently unavailable.',
        variant: 'destructive',
      });
      return;
    }
    addToCart(product, 1);
    toast({
      title: 'Added to Cart',
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleServiceRequest = () => {
    if (serviceDescription.trim() && onServiceRequest) {
      onServiceRequest(product.id, serviceDescription);
      setServiceDescription('');
      setShowServiceDialog(false);
      toast({
        title: 'Service Request Submitted',
        description: 'Our team will contact you soon.',
      });
    }
  };

  return (
    <>
      <Card className="overflow-hidden hover-elevate transition-all duration-200 shadow-md" data-testid={`card-product-${product.id}`}>
        <div className="relative aspect-[4/3] overflow-hidden bg-muted">
          <img
            src={`${product.image_url}?w=400&h=400&fit=crop`} // <-- Fixed here
            alt={product.name || 'Product'}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src = '/images/fallback-product.png';
            }}
            data-testid={`img-product-${product.id}`}
          />
          <Badge 
            variant={product.stock > 10 ? 'default' : product.stock > 0 ? 'secondary' : 'destructive'}
            className="absolute top-3 right-3 rounded-full shadow-sm"
            data-testid={`badge-stock-${product.id}`}
          >
            {product.stock > 0 ? `${product.stock} in stock` : 'Out of Stock'}
          </Badge>
        </div>

        <CardContent className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-lg leading-tight" data-testid={`text-product-name-${product.id}`}>
              {product.name}
            </h3>
            <p className="text-sm text-muted-foreground capitalize" data-testid={`text-product-type-${product.id}`}>
              {product.type}
            </p>
          </div>
          {product.description && (
            <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-product-description-${product.id}`}>
              {product.description}
            </p>
          )}
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold text-primary" data-testid={`text-product-price-${product.id}`}>
              ₱{parseFloat(product.price).toFixed(2)}
            </span>
            {product.alcoholContent && (
              <span className="text-sm text-muted-foreground" data-testid={`text-product-alcohol-${product.id}`}>
                {product.alcoholContent}
              </span>
            )}
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0 flex flex-col gap-2">
          <Button 
            className="w-full rounded-full gap-2" 
            onClick={handleBuyNow}
            disabled={product.stock <= 0}
            data-testid={`button-buy-${product.id}`}
          >
            <ShoppingCart className="w-4 h-4" />
            {product.stock > 0 ? 'Buy Now' : 'Out of Stock'}
          </Button>
          <Button 
            variant="outline" 
            className="w-full rounded-full gap-2"
            onClick={() => setShowServiceDialog(true)}
            data-testid={`button-service-${product.id}`}
          >
            <Wrench className="w-4 h-4" />
            Request Service
          </Button>
        </CardFooter>
      </Card>

      <Dialog open={showServiceDialog} onOpenChange={setShowServiceDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Request Service</DialogTitle>
            <DialogDescription>
              Need help with {product.name}? Describe your request below.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="service-description">Description</Label>
              <Textarea
                id="service-description"
                value={serviceDescription}
                onChange={(e) => setServiceDescription(e.target.value)}
                placeholder="Describe the service you need..."
                className="min-h-24"
                data-testid="textarea-service-description"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowServiceDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleServiceRequest} disabled={!serviceDescription.trim()} data-testid="button-submit-service">
              Submit Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
