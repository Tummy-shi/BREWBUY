import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  Home, 
  ShoppingCart, 
  MessageCircle, 
  Package, 
  History, 
  Info, 
  Users, 
  Phone,
  LogOut,
  X
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const { user, signOut } = useAuth();
  const { totalItems } = useCart();

  const handleNavigation = (path: string) => {
    setLocation(path);
    onClose();
  };

  const handleSignOut = async () => {
    await signOut();
    setLocation('/login');
  };

  const menuItems = [
    { icon: Home, label: 'Dashboard', path: '/dashboard' },
    { icon: ShoppingCart, label: 'Cart', path: '/cart', badge: totalItems },
    { icon: MessageCircle, label: 'Live Chat', path: '/chat' },
    { icon: Package, label: 'Track Orders', path: '/tracking' },
    { icon: History, label: 'Company History', path: '/company-history' },
    { icon: Info, label: 'About Our Products', path: '/about-products' },
    { icon: Info, label: 'About the App', path: '/about-app' },
    { icon: Users, label: 'Developers', path: '/developers' },
    { icon: Phone, label: 'Contact Us', path: '/contact' },
  ];

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={onClose}
          data-testid="overlay-sidebar"
        />
      )}
      <div
        className={`fixed top-0 left-0 h-full w-80 bg-card border-r border-card-border shadow-xl z-50 transform transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        data-testid="sidebar-menu"
      >
        <div className="flex flex-col h-full">
          <div className="p-6 flex justify-between items-center border-b border-card-border">
            <h2 className="text-xl font-bold" data-testid="text-sidebar-title">Menu</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="rounded-full"
              data-testid="button-close-sidebar"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="p-6 border-b border-card-border">
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={user?.user_metadata?.profile_image} />
                <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                  {user?.user_metadata?.full_name?.charAt(0) || user?.email?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-base truncate" data-testid="text-user-name">
                  {user?.user_metadata?.full_name || 'User'}
                </p>
                <p className="text-sm text-muted-foreground truncate" data-testid="text-user-email">
                  {user?.email}
                </p>
                {user?.user_metadata?.phone && (
                  <p className="text-sm text-muted-foreground" data-testid="text-user-phone">
                    {user.user_metadata.phone}
                  </p>
                )}
              </div>
            </div>
          </div>

          <nav className="flex-1 overflow-y-auto p-4">
            <ul className="space-y-2">
              {menuItems.map((item) => (
                <li key={item.path}>
                  <Button
                    variant={location === item.path ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3 rounded-lg"
                    onClick={() => handleNavigation(item.path)}
                    data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.badge !== undefined && item.badge > 0 && (
                      <span className="bg-primary text-primary-foreground text-xs font-semibold px-2 py-1 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </Button>
                </li>
              ))}
            </ul>
          </nav>

          <Separator />
          
          <div className="p-4">
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-destructive hover:text-destructive rounded-lg"
              onClick={handleSignOut}
              data-testid="button-logout"
            >
              <LogOut className="w-5 h-5" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
