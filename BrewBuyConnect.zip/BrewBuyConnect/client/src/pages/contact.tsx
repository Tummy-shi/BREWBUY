import { useState } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sidebar } from '@/components/Sidebar';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function Contact() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();

  const contactMethods = [
    {
      icon: Mail,
      title: 'Email',
      value: 'support@brewbuy.com',
      description: 'Send us an email anytime',
    },
    {
      icon: Phone,
      title: 'Phone',
      value: '1-800-BREWBUY',
      description: 'Call us Mon-Fri, 9AM-6PM',
    },
    {
      icon: MapPin,
      title: 'Address',
      value: '123 Brewery Lane, Craft City, BC 12345',
      description: 'Visit our office',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">Contact Us</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-8 max-w-2xl mx-auto space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-4">Get in Touch</h2>
          <p className="text-muted-foreground leading-relaxed">
            Have questions, feedback, or need assistance? We're here to help! Reach out to us through any of the 
            following channels.
          </p>
        </div>

        <div className="space-y-4">
          {contactMethods.map((method) => (
            <Card key={method.title} className="hover-elevate">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <div className="p-3 bg-primary/10 rounded-xl flex-shrink-0 h-fit">
                    <method.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-base mb-1">{method.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{method.description}</p>
                    <p className="font-medium text-foreground break-words">{method.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-6">
            <h3 className="font-semibold text-base mb-2">Live Chat Available</h3>
            <p className="text-sm text-muted-foreground mb-4">
              For immediate assistance, use our Live Chat feature available in the app menu. Our support team 
              typically responds within minutes during business hours.
            </p>
            <Button 
              className="rounded-full"
              onClick={() => setLocation('/chat')}
              data-testid="button-start-chat"
            >
              Start Live Chat
            </Button>
          </CardContent>
        </Card>

        <div className="pt-4">
          <h3 className="text-xl font-semibold mb-3">Business Hours</h3>
          <div className="space-y-2 text-muted-foreground">
            <div className="flex justify-between">
              <span>Monday - Friday</span>
              <span className="font-medium">9:00 AM - 6:00 PM</span>
            </div>
            <div className="flex justify-between">
              <span>Saturday</span>
              <span className="font-medium">10:00 AM - 4:00 PM</span>
            </div>
            <div className="flex justify-between">
              <span>Sunday</span>
              <span className="font-medium">Closed</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
