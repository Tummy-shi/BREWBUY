import { useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { cart, totalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState('');

  const tax = totalPrice * 0.1;
  const shipping = 5.99;
  const total = totalPrice + tax + shipping;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || cart.length === 0) return;

    setLoading(true);
    try {
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          total_amount: total.toFixed(2),
          shipping_address: address,
          status: 'pending',
        })
        .select()
        .single();

      if (orderError) throw orderError;

      const orderItems = cart.map(item => ({
        order_id: order.id,
        product_id: item.product.id,
        quantity: item.quantity,
        price_at_purchase: item.product.price,
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) throw itemsError;

      for (const item of cart) {
        await supabase
          .from('products')
          .update({ stock: item.product.stock - item.quantity })
          .eq('id', item.product.id);
      }

      clearCart();
      toast({
        title: 'Order Placed Successfully!',
        description: 'Your order has been confirmed. Track it in the Orders page.',
      });
      setLocation('/tracking');
    } catch (error: any) {
      toast({
        title: 'Checkout Failed',
        description: error.message || 'An error occurred during checkout.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    setLocation('/cart');
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center gap-3 h-16 px-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation('/cart')}
            className="rounded-full"
            data-testid="button-back"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
          <h1 className="text-xl font-bold" data-testid="text-header-title">Checkout</h1>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        <form onSubmit={handleCheckout} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Shipping Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address">Delivery Address</Label>
                <Input
                  id="address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Enter your full delivery address"
                  required
                  className="rounded-lg"
                  data-testid="input-address"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart.map((item) => (
                <div key={item.product.id} className="flex justify-between items-center" data-testid={`item-summary-${item.product.id}`}>
                  <div>
                    <p className="font-medium" data-testid={`text-item-name-${item.product.id}`}>{item.product.name}</p>
                    <p className="text-sm text-muted-foreground" data-testid={`text-item-quantity-${item.product.id}`}>
                      Quantity: {item.quantity}
                    </p>
                  </div>
                  <p className="font-semibold" data-testid={`text-item-total-${item.product.id}`}>
                    ${(parseFloat(item.product.price) * item.quantity).toFixed(2)}
                  </p>
                </div>
              ))}
              <Separator />
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span data-testid="text-summary-subtotal">${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax (10%)</span>
                  <span data-testid="text-summary-tax">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span data-testid="text-summary-shipping">${shipping.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-primary" data-testid="text-summary-total">${total.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6">
              <p className="text-sm text-center text-muted-foreground mb-4">
                This is a mock checkout. No actual payment will be processed.
              </p>
              <Button 
                type="submit" 
                className="w-full rounded-full" 
                size="lg"
                disabled={loading}
                data-testid="button-place-order"
              >
                {loading ? 'Processing...' : 'Place Order'}
              </Button>
            </CardContent>
          </Card>
        </form>
      </main>
    </div>
  );
}
