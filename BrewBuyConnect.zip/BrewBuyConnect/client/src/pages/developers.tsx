import { useState } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, Code2, Smartphone, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sidebar } from '@/components/Sidebar';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function Developers() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">Developers</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-8 max-w-2xl mx-auto space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-4">Development Team</h2>
          <p className="text-muted-foreground leading-relaxed">
            BrewBuy was built by a passionate team of developers dedicated to creating exceptional user experiences 
            through clean code and modern design principles.
          </p>
        </div>

        <Card className="hover-elevate">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-xl flex-shrink-0">
                <Code2 className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Frontend Development</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  Built with React, TypeScript, and TailwindCSS, focusing on performance, accessibility, and 
                  beautiful design.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">React</span>
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">TypeScript</span>
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">TailwindCSS</span>
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">Vite</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-xl flex-shrink-0">
                <Database className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Backend & Database</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  Powered by Supabase, providing real-time updates, secure authentication, and scalable data storage.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">Supabase</span>
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">PostgreSQL</span>
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">Realtime</span>
                  <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">Auth</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-xl flex-shrink-0">
                <Smartphone className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Mobile-First Approach</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Designed with a mobile-first philosophy, ensuring a seamless experience across all devices from 
                  smartphones to desktop computers.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="pt-4">
          <h3 className="text-xl font-semibold mb-3">Open Source</h3>
          <p className="text-muted-foreground leading-relaxed">
            We believe in the power of open-source development and contributing to the developer community. This 
            project showcases modern web development best practices and patterns.
          </p>
        </div>
      </main>
    </div>
  );
}
