import { useState } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sidebar } from '@/components/Sidebar';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function CompanyHistory() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">Company History</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-8 max-w-2xl mx-auto">
        <div className="prose prose-sm max-w-none">
          <h2 className="text-2xl font-bold mb-4">Our Story</h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            Founded in 2020, BrewBuy began with a simple mission: to bring the finest selection of craft beers, 
            ales, and ciders directly to enthusiasts and casual drinkers alike. What started as a small local 
            operation has grown into a trusted online platform serving thousands of customers.
          </p>

          <h3 className="text-xl font-semibold mb-3 mt-8">Our Journey</h3>
          <p className="text-muted-foreground leading-relaxed mb-4">
            From our humble beginnings in a small warehouse, we've expanded our inventory to include hundreds of 
            premium beverages from around the world. Our commitment to quality and customer satisfaction has been 
            the cornerstone of our success.
          </p>

          <h3 className="text-xl font-semibold mb-3 mt-8">Our Values</h3>
          <ul className="space-y-3 text-muted-foreground">
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">•</span>
              <span><strong>Quality First:</strong> We partner only with trusted breweries and cideries that share our commitment to excellence.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">•</span>
              <span><strong>Customer Service:</strong> Our dedicated support team is always ready to help with your orders and inquiries.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">•</span>
              <span><strong>Innovation:</strong> We continuously improve our platform with features like real-time stock updates and live chat support.</span>
            </li>
          </ul>

          <h3 className="text-xl font-semibold mb-3 mt-8">Looking Forward</h3>
          <p className="text-muted-foreground leading-relaxed">
            As we continue to grow, our focus remains on providing an exceptional shopping experience, expanding 
            our product selection, and supporting local and international breweries. Thank you for being part of 
            our journey.
          </p>
        </div>
      </main>
    </div>
  );
}
