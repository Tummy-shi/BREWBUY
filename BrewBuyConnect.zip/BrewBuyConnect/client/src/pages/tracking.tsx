import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, Package, Truck, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sidebar } from '@/components/Sidebar';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Skeleton } from '@/components/ui/skeleton';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

interface Order {
  id: string;
  status: string;
  total_amount: string;
  shipping_address: string;
  created_at: string;
  updated_at: string;
}

interface ServiceRequest {
  id: string;
  status: string;
  description: string;
  created_at: string;
  updated_at: string;
  products: { name: string } | null;
}

export default function Tracking() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadOrdersAndServices();

      const ordersChannel = supabase
        .channel('orders-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'orders',
          filter: `user_id=eq.${user.id}`
        }, () => {
          loadOrdersAndServices();
        })
        .subscribe();

      const servicesChannel = supabase
        .channel('services-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'service_requests',
          filter: `user_id=eq.${user.id}`
        }, () => {
          loadOrdersAndServices();
        })
        .subscribe();

      return () => {
        supabase.removeChannel(ordersChannel);
        supabase.removeChannel(servicesChannel);
      };
    }
  }, [user]);

  const loadOrdersAndServices = async () => {
    if (!user) return;

    const { data: ordersData } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    const { data: servicesData } = await supabase
      .from('service_requests')
      .select('*, products(name)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (ordersData) setOrders(ordersData as Order[]);
    if (servicesData) setServiceRequests(servicesData as ServiceRequest[]);
    setLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-5 h-5" />;
      case 'processing': case 'in_progress': return <Package className="w-5 h-5" />;
      case 'shipped': return <Truck className="w-5 h-5" />;
      case 'delivered': case 'resolved': return <CheckCircle className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'secondary';
      case 'processing': case 'in_progress': return 'default';
      case 'shipped': return 'default';
      case 'delivered': case 'resolved': return 'default';
      default: return 'secondary';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">Track Orders</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        <section>
          <h2 className="text-xl font-bold mb-4" data-testid="text-orders-title">My Orders</h2>
          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <Skeleton className="h-6 w-1/3 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : orders.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground" data-testid="text-no-orders">No orders yet</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <Card key={order.id} className="hover-elevate" data-testid={`card-order-${order.id}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(order.status)}
                        <CardTitle className="text-base">Order #{order.id.slice(0, 8)}</CardTitle>
                      </div>
                      <Badge variant={getStatusColor(order.status) as any} className="rounded-full capitalize" data-testid={`badge-order-status-${order.id}`}>
                        {order.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Total</span>
                      <span className="font-semibold" data-testid={`text-order-total-${order.id}`}>${parseFloat(order.total_amount).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Address</span>
                      <span className="text-right max-w-[60%] truncate" data-testid={`text-order-address-${order.id}`}>{order.shipping_address}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Date</span>
                      <span data-testid={`text-order-date-${order.id}`}>{new Date(order.created_at).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>

        <section>
          <h2 className="text-xl font-bold mb-4" data-testid="text-services-title">Service Requests</h2>
          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <Skeleton className="h-6 w-1/3 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : serviceRequests.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground" data-testid="text-no-services">No service requests yet</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {serviceRequests.map((request) => (
                <Card key={request.id} className="hover-elevate" data-testid={`card-service-${request.id}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(request.status)}
                        <CardTitle className="text-base">Request #{request.id.slice(0, 8)}</CardTitle>
                      </div>
                      <Badge variant={getStatusColor(request.status) as any} className="rounded-full capitalize" data-testid={`badge-service-status-${request.id}`}>
                        {request.status.replace('_', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {request.products && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Product</span>
                        <span className="font-medium" data-testid={`text-service-product-${request.id}`}>{request.products.name}</span>
                      </div>
                    )}
                    <div className="text-sm">
                      <span className="text-muted-foreground">Description</span>
                      <p className="mt-1" data-testid={`text-service-description-${request.id}`}>{request.description}</p>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Date</span>
                      <span data-testid={`text-service-date-${request.id}`}>{new Date(request.created_at).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
