import { useState } from 'react';
import { useLocation } from 'wouter';
import { Menu, Trash2, Plus, Minus, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Sidebar } from '@/components/Sidebar';
import { useCart } from '@/contexts/CartContext';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function Cart() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { cart, updateQuantity, removeFromCart, totalPrice } = useCart();
  const [, setLocation] = useLocation();

  const tax = totalPrice * 0.1; // 10% tax
  const shipping = cart.length > 0 ? 5.99 : 0;
  const total = totalPrice + tax + shipping;

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">Shopping Cart</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        {cart.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg mb-6" data-testid="text-empty-cart">
              Your cart is empty
            </p>
            <Button onClick={() => setLocation('/dashboard')} className="rounded-full" data-testid="button-continue-shopping">
              Continue Shopping
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-4">
              {cart.map((item) => (
                <Card key={item.product.id} className="overflow-hidden" data-testid={`card-cart-item-${item.product.id}`}>
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <img
                        src={item.product.imageUrl}
                        alt={item.product.name}
                        className="w-20 h-20 rounded-lg object-cover bg-muted"
                        data-testid={`img-cart-item-${item.product.id}`}
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-base leading-tight mb-1" data-testid={`text-cart-item-name-${item.product.id}`}>
                          {item.product.name}
                        </h3>
                        <p className="text-sm text-muted-foreground capitalize mb-2" data-testid={`text-cart-item-type-${item.product.id}`}>
                          {item.product.type}
                        </p>
                        <p className="text-lg font-bold text-primary" data-testid={`text-cart-item-price-${item.product.id}`}>
                          ${parseFloat(item.product.price).toFixed(2)}
                        </p>
                      </div>
                      <div className="flex flex-col items-end justify-between">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="rounded-full text-destructive hover:text-destructive"
                          onClick={() => removeFromCart(item.product.id)}
                          data-testid={`button-remove-${item.product.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            data-testid={`button-decrease-${item.product.id}`}
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-8 text-center font-semibold" data-testid={`text-quantity-${item.product.id}`}>
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            disabled={item.quantity >= item.product.stock}
                            data-testid={`button-increase-${item.product.id}`}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="shadow-lg sticky bottom-4">
              <CardContent className="p-6 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-medium" data-testid="text-subtotal">${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax (10%)</span>
                  <span className="font-medium" data-testid="text-tax">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="font-medium" data-testid="text-shipping">${shipping.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-primary" data-testid="text-total">${total.toFixed(2)}</span>
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0">
                <Button 
                  className="w-full rounded-full" 
                  size="lg"
                  onClick={() => setLocation('/checkout')}
                  data-testid="button-checkout"
                >
                  Proceed to Checkout
                </Button>
              </CardFooter>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
