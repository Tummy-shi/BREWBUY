import { useState } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, Beer, Wine, Droplet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sidebar } from '@/components/Sidebar';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function AboutProducts() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();

  const productTypes = [
    {
      icon: Beer,
      title: 'Craft Beers',
      description: 'Our curated selection of craft beers includes IPAs, lagers, stouts, and more from renowned breweries worldwide.',
    },
    {
      icon: Wine,
      title: 'Premium Ales',
      description: 'Discover our range of traditional and modern ales, carefully selected for their unique flavors and brewing excellence.',
    },
    {
      icon: Droplet,
      title: 'Artisan Ciders',
      description: 'From crisp apple ciders to innovative fruit blends, our cider collection offers something for every palate.',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">About Our Products</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-8 max-w-2xl mx-auto space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-4">Premium Selection</h2>
          <p className="text-muted-foreground leading-relaxed">
            At BrewBuy, we take pride in offering only the finest beers, ales, and ciders. Every product in our 
            catalog is carefully selected based on quality, taste, and authenticity.
          </p>
        </div>

        <div className="space-y-4">
          {productTypes.map((type) => (
            <Card key={type.title} className="hover-elevate">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <type.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{type.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">{type.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="pt-4">
          <h3 className="text-xl font-semibold mb-3">Quality Assurance</h3>
          <p className="text-muted-foreground leading-relaxed mb-4">
            All our products are stored in optimal conditions and shipped with care to ensure they reach you in 
            perfect condition. We maintain strict quality control standards throughout our supply chain.
          </p>
          
          <h3 className="text-xl font-semibold mb-3 mt-6">Real-Time Stock Updates</h3>
          <p className="text-muted-foreground leading-relaxed">
            Our platform features real-time inventory tracking, so you always know what's available. Popular items 
            sell fast, so we recommend adding favorites to your cart quickly!
          </p>
        </div>
      </main>
    </div>
  );
}
