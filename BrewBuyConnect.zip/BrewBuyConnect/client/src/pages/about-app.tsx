import { useState } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, Smartphone, ShoppingBag, MessageCircle, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sidebar } from '@/components/Sidebar';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function AboutApp() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: Smartphone,
      title: 'Mobile-First Design',
      description: 'Optimized for mobile devices with an Ionic-inspired interface that feels like a native app.',
    },
    {
      icon: ShoppingBag,
      title: 'Seamless Shopping',
      description: 'Easy browsing, quick add-to-cart, and streamlined checkout for a smooth shopping experience.',
    },
    {
      icon: MessageCircle,
      title: 'Live Chat Support',
      description: 'Connect with our support team in real-time for instant help with orders or questions.',
    },
    {
      icon: TrendingUp,
      title: 'Real-Time Updates',
      description: 'Stock counts and order statuses update automatically, keeping you informed every step of the way.',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">About the App</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="px-4 py-8 max-w-2xl mx-auto space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-4">BrewBuy Mobile App</h2>
          <p className="text-muted-foreground leading-relaxed">
            BrewBuy is designed to bring the convenience of online shopping to craft beer, ale, and cider 
            enthusiasts. Built with modern web technologies, our app delivers a fast, responsive, and intuitive 
            experience on any device.
          </p>
        </div>

        <div className="grid gap-4">
          {features.map((feature) => (
            <Card key={feature.title} className="hover-elevate">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <div className="p-3 bg-primary/10 rounded-xl flex-shrink-0 h-fit">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-base mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="pt-4">
          <h3 className="text-xl font-semibold mb-3">Technology Stack</h3>
          <p className="text-muted-foreground leading-relaxed">
            Built with React, TailwindCSS, and powered by Supabase for real-time features, authentication, and 
            data management. The app combines the best of modern web development to deliver a premium user experience.
          </p>
        </div>
      </main>
    </div>
  );
}
