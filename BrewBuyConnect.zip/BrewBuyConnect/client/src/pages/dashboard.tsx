import { useState, useEffect } from 'react';
import { Menu, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sidebar } from '@/components/Sidebar';
import { ProductCard } from '@/components/ProductCard';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Skeleton } from '@/components/ui/skeleton';
import type { Product } from '@shared/schema';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';
import { useLocation } from 'wouter';

export default function Dashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { totalItems } = useCart();
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    loadProducts();
    
    const channel = supabase
      .channel('products-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, () => {
        loadProducts();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadProducts = async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setProducts(data as Product[]);
    }
    setLoading(false);
  };

  const handleServiceRequest = async (productId: string, description: string) => {
    if (!user) return;

    await supabase.from('service_requests').insert({
      user_id: user.id,
      product_id: productId,
      description,
      status: 'pending',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="sticky top-0 z-30 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsSidebarOpen(true)}
              className="rounded-full"
              data-testid="button-menu"
            >
              <Menu className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" data-testid="img-header-logo" />
            <h1 className="text-xl font-bold" data-testid="text-header-title">BrewBuy</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full relative"
            onClick={() => setLocation('/cart')}
            data-testid="button-cart"
          >
            <ShoppingCart className="w-6 h-6" />
            {totalItems > 0 && (
              <Badge 
                className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 rounded-full text-xs"
                data-testid="badge-cart-count"
              >
                {totalItems}
              </Badge>
            )}
          </Button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-7xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2" data-testid="text-page-title">Our Products</h2>
          <p className="text-muted-foreground" data-testid="text-page-description">
            Browse our selection of premium beers, ales, and ciders
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="aspect-[4/3] w-full" />
                <div className="p-4 space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-8 w-1/3" />
                </div>
              </Card>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg" data-testid="text-no-products">
              No products available at the moment.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product}
                onServiceRequest={handleServiceRequest}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`bg-card border border-card-border rounded-xl ${className}`}>{children}</div>;
}
