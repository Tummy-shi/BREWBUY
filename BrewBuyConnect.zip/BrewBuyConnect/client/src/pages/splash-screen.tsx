import { useEffect } from 'react';
import { useLocation } from 'wouter';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';

export default function SplashScreen() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      setLocation('/login');
    }, 2000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-primary/10 to-background animate-in fade-in duration-300">
      <div className="flex flex-col items-center gap-6 animate-in zoom-in duration-500">
        <img 
          src={appIconImage} 
          alt="BrewBuy App Icon" 
          className="w-24 h-24 rounded-2xl shadow-2xl"
          data-testid="img-app-icon"
        />
        <h1 className="text-4xl font-bold text-foreground" data-testid="text-app-name">
          BrewBuy
        </h1>
        <p className="text-muted-foreground text-sm" data-testid="text-tagline">
          Premium Beer, Ale & Cider
        </p>
        <div className="flex gap-2 mt-8">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: '200ms' }}></div>
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: '400ms' }}></div>
        </div>
      </div>
    </div>
  );
}
