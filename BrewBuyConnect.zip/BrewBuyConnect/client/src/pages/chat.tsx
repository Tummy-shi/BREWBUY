import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { Menu, ArrowLeft, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sidebar } from '@/components/Sidebar';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import appIconImage from '@assets/generated_images/BrewBuy_app_icon_73644766.png';
import staffAvatarImage from '@assets/generated_images/Staff_member_avatar_1e8d3c07.png';

interface ChatMessage {
  id: string;
  user_id: string;
  message: string;
  is_staff: boolean;
  created_at: string;
}

export default function Chat() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      loadMessages();

      const channel = supabase
        .channel('chat-messages')
        .on('postgres_changes', { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'chat_messages'
        }, (payload) => {
          setMessages(prev => [...prev, payload.new as ChatMessage]);
        })
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadMessages = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true });

    if (data) setMessages(data as ChatMessage[]);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || sending) return;

    setSending(true);
    try {
      await supabase.from('chat_messages').insert({
        user_id: user.id,
        message: newMessage.trim(),
        is_staff: false,
      });

      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <header className="flex-shrink-0 bg-card border-b border-card-border shadow-sm">
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
              className="rounded-full"
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <img src={appIconImage} alt="BrewBuy" className="w-8 h-8 rounded-lg" />
            <div>
              <h1 className="text-lg font-bold" data-testid="text-header-title">Live Chat</h1>
              <p className="text-xs text-muted-foreground">Customer Support</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(true)}
            className="rounded-full"
            data-testid="button-menu"
          >
            <Menu className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-muted-foreground" data-testid="text-no-messages">
                No messages yet. Start a conversation!
              </p>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.is_staff ? 'justify-start' : 'justify-end'}`}
                data-testid={`message-${msg.id}`}
              >
                {msg.is_staff && (
                  <Avatar className="w-10 h-10 flex-shrink-0">
                    <AvatarImage src={staffAvatarImage} />
                    <AvatarFallback className="bg-primary text-primary-foreground">S</AvatarFallback>
                  </Avatar>
                )}
                <div className={`flex flex-col max-w-xs ${msg.is_staff ? 'items-start' : 'items-end'}`}>
                  <div
                    className={`px-4 py-3 rounded-2xl ${
                      msg.is_staff
                        ? 'bg-card border border-card-border'
                        : 'bg-primary text-primary-foreground'
                    }`}
                    data-testid={`text-message-content-${msg.id}`}
                  >
                    <p className="text-sm leading-relaxed break-words">{msg.message}</p>
                  </div>
                  <span className="text-xs text-muted-foreground mt-1 px-2" data-testid={`text-message-time-${msg.id}`}>
                    {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                {!msg.is_staff && (
                  <Avatar className="w-10 h-10 flex-shrink-0">
                    <AvatarImage src={user?.user_metadata?.profile_image} />
                    <AvatarFallback className="bg-secondary text-secondary-foreground">
                      {user?.user_metadata?.full_name?.charAt(0) || user?.email?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      <footer className="flex-shrink-0 bg-card border-t border-card-border shadow-lg">
        <form onSubmit={handleSendMessage} className="max-w-2xl mx-auto p-4">
          <div className="flex gap-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="rounded-full flex-1"
              disabled={sending}
              data-testid="input-message"
            />
            <Button 
              type="submit" 
              size="icon" 
              className="rounded-full flex-shrink-0"
              disabled={!newMessage.trim() || sending}
              data-testid="button-send"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </form>
      </footer>
    </div>
  );
}
