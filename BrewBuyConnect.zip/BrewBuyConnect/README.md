# BrewBuy - Premium Beer, Ale & Cider E-Commerce

A beautiful, mobile-first web application for purchasing craft beers, ales, and ciders. Built with React, TailwindCSS, and Supabase.

## 🎯 Features

- **User Authentication** - Secure email/password signup and login
- **Product Catalog** - Browse premium beers, ales, and ciders with real-time stock counts
- **Shopping Cart** - Add items, adjust quantities, and manage your cart
- **Seamless Checkout** - Review orders and complete purchases with ease
- **Order Tracking** - Monitor order status with real-time updates
- **Service Requests** - Request assistance for any product
- **Live Chat** - Get instant support from our team via real-time messaging
- **Mobile-First Design** - Ionic-inspired UI that looks great on all devices
- **Real-Time Updates** - Stock counts and order statuses update automatically

## 🚀 Quick Start

### Prerequisites
- Supabase account (free tier works great)
- The Supabase credentials are already configured in your Replit Secrets

### Database Setup (Required)

**Important:** You must set up the database tables before using the app!

1. Go to your Supabase project at https://supabase.com
2. Navigate to "SQL Editor" in the sidebar
3. Click "New Query"
4. Open the `supabase-setup.sql` file in this project
5. Copy all the SQL code and paste it into the editor
6. Click "Run" to execute

This creates:
- All database tables with proper relationships
- Row Level Security policies for data protection
- Performance indexes
- 6 sample products to get started

### Enable Real-Time Features (Recommended)

For live chat and stock updates:
1. In Supabase, go to "Database" → "Replication"
2. Enable replication for these tables:
   - `products` (real-time stock updates)
   - `chat_messages` (live messaging)
   - `orders` (order status updates)
   - `service_requests` (service tracking)

### Running the Application

The app is already running! Just click the preview window.

1. **Create Account** - Start at the splash screen, sign up with email/password
2. **Browse Products** - View available beers, ales, and ciders
3. **Shop** - Add items to cart and checkout
4. **Track Orders** - Monitor your order status
5. **Get Support** - Use live chat for assistance

## 📱 User Guide

### Authentication
- Sign up with email and password
- Profile includes name and optional phone number
- Secure authentication via Supabase Auth

### Shopping Experience
- Browse product catalog with high-quality images
- Real-time stock counts show availability
- Add items directly to cart or buy now
- Cart persists between sessions

### Checkout
- Review order summary with itemized pricing
- Enter shipping address
- See total including tax and shipping
- Orders are created immediately upon confirmation

### Order & Service Tracking
- View all your orders with current status
- Track service requests
- Real-time status updates
- Timeline view of order progress

### Live Chat
- Instant messaging with support staff
- Real-time message delivery
- Message history per user
- Typing indicators and timestamps

### Navigation
- Hamburger menu with full navigation
- Profile section shows your info
- Access all pages: Products, Cart, Chat, Tracking, and more
- Static pages: Company History, About Products, About App, Developers, Contact

## 🛠️ Technology Stack

- **Frontend:** React 18, TypeScript, TailwindCSS
- **Routing:** Wouter
- **State Management:** React Context, TanStack Query
- **Backend:** Supabase (PostgreSQL, Auth, Realtime)
- **UI Components:** Shadcn/ui with custom theming
- **Icons:** Lucide React
- **Build Tool:** Vite

## 🎨 Design System

- **Primary Color:** Amber/Orange (#D97706)
- **Typography:** Inter for UI, Roboto for content
- **Border Radius:** Rounded elements (8-16px)
- **Shadows:** Subtle elevation
- **Mobile-First:** Responsive from 320px to 4K
- **Ionic-Inspired:** Native mobile app feel

## 📁 Project Structure

```
├── client/
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   │   ├── ui/          # Shadcn components
│   │   │   ├── Sidebar.tsx
│   │   │   └── ProductCard.tsx
│   │   ├── contexts/        # React contexts
│   │   │   ├── AuthContext.tsx
│   │   │   └── CartContext.tsx
│   │   ├── lib/             # Utilities
│   │   │   ├── supabase.ts
│   │   │   └── queryClient.ts
│   │   ├── pages/           # Route components
│   │   │   ├── splash-screen.tsx
│   │   │   ├── login.tsx
│   │   │   ├── dashboard.tsx
│   │   │   ├── cart.tsx
│   │   │   ├── checkout.tsx
│   │   │   ├── tracking.tsx
│   │   │   ├── chat.tsx
│   │   │   └── [static pages]
│   │   ├── App.tsx          # Main app with routing
│   │   └── index.css        # Global styles
│   └── index.html
├── shared/
│   └── schema.ts            # TypeScript types & schemas
├── attached_assets/
│   └── generated_images/    # Product & app images
├── supabase-setup.sql       # Database setup script
└── SETUP_INSTRUCTIONS.md    # Detailed setup guide
```

## 🔐 Security

- Row Level Security (RLS) enabled on all tables
- Users can only access their own data
- Products are publicly readable
- Secure password hashing via Supabase Auth
- Environment variables for sensitive credentials

## 🐛 Troubleshooting

**Can't see products?**
- Ensure you ran the `supabase-setup.sql` script
- Check that RLS policies were created
- Verify products table has data

**Authentication not working?**
- Check Supabase Auth is enabled for email/password
- Go to Supabase → Authentication → Settings
- Enable "Email Auth"

**Real-time features not working?**
- Enable Realtime in Supabase for relevant tables
- Check browser console for connection errors
- Ensure you're on a supported browser

**Chat messages not appearing?**
- Verify `chat_messages` table has Realtime enabled
- Check RLS policies allow reading your messages

## 📝 Sample Data

The setup script includes 6 sample products:
- Craft IPA Premium (Beer)
- Golden Ale Classic (Ale)
- Apple Orchard Cider (Cider)
- Dark Stout Reserve (Beer)
- Wheat Beer Summer (Beer)
- Amber Ale Bold (Ale)

You can add more products via the Supabase Table Editor.

## 🎯 Next Steps

After setup, try:
1. Create an account
2. Browse and add products to cart
3. Complete a purchase
4. Submit a service request
5. Use live chat
6. Track your orders

## 📄 License

This project is open source and available for educational purposes.

## 🤝 Support

Need help? Use the live chat feature in the app or check the Contact Us page for more information.

---

Built with ❤️ using React, TailwindCSS, and Supabase
